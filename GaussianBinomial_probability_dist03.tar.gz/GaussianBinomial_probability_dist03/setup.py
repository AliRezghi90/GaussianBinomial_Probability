from setuptools import setup

setup(name='GaussianBinomial_probability_dist03',
      version='0.3',
      description='Gaussian and Binomial distributions',
      packages=['GaussianBinomial_probability_dist03'],
      author = 'Ali Rezghi',
      zip_safe=False)
