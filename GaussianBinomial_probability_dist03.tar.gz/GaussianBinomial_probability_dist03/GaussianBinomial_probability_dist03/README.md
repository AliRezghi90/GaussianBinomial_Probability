Summary of the package:

# Files and Explanations:
- Binomialdistribution.py: contains the code to perform Binomial distribution on a data set
- Gaussiandistribution: contains the code to perform Guassian distribution on a data set
- Generaldistribution: the parent class for Gaussiandistribution and Binomialdistribution
- lincense.txt: explains the license to use the package

# Installation:
pip install GaussianBinomial_probability

